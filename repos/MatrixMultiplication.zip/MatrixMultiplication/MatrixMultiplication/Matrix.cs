﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MatrixMultiplication
{
    class Matrix
    {
        public int[,] MyMatrix (int height, int lenth)
        {
            Random myRnd = new Random(Environment.TickCount);
            int[,] FullMatrix = new int[height, lenth];

            for (int i = 0; i < height; i++)
            {
                for (int j = 0; j < lenth; j++)
                {
                    FullMatrix[i, j] = myRnd.Next(0, 10);
                    //Console.Write($"{FullMatrix[i, j]} \t");
                }
               // Console.Write("\n");
            }
            return FullMatrix;
        }

        public int MultMatrixElem (int[,] matrix1, int[,] matrix2, int i, int j, int lenth1)
        {
            int mme = 0;
            for (int k = 0; k < lenth1; k++)
            {
                mme += matrix1[i, k] * matrix2[k, j];
            }

            return mme;
        }

        public void MatrixOut (int[,] matrix, int height, int lenth)
        {
            for (int i = 0; i < height; i++)
            {
                for (int j = 0; j < lenth; j++)
                {
                    Console.Write($"{matrix[i, j]} \t");
                }
                 Console.Write("\n");
            }
        }
    }
}
