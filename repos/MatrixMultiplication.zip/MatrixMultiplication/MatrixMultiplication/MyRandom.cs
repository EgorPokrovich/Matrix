﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MatrixMultiplication
{
    class MyRandom
    {
        private static readonly int seed = Environment.TickCount;
        private static readonly Random myRnd = new Random(Environment.TickCount);

        public static int getRnd ()
        {
            return myRnd.Next(0, 2);
        }
    }
}
*/