﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MatrixMultiplication
{
    class Program
    {
      /*  
       *  private static int Ranran()
        {
            Random rnd = new Random(Environment.TickCount);
            int i = rnd.Next(0, 2);
            return i;
        }
        */
        static void Main(string[] args)
        {
            int height1, lenth1, height2, lenth2;
            height1 = lenth1 = height2 = lenth2 = 0; 

            try
            {
                height1 = Convert.ToInt32(args[0]);
                lenth1 = Convert.ToInt32(args[1]);
                height2 = Convert.ToInt32(args[2]);
                lenth2 = Convert.ToInt32(args[3]);
                // Console.WriteLine($"введен параметр {lenth}");
            }
            catch
            {
                Console.WriteLine("Не корректный параметр!");
            }

            Matrix FirstMatrix = new Matrix();
            Matrix SecondMatrix = new Matrix();

          //  try
          //  {
                int [,] fm = FirstMatrix.MyMatrix(height1, lenth1);
                Console.Write("\n");
                Console.Write("\n");
                int [,] sm = SecondMatrix.MyMatrix(height2, lenth2);
         /*   }
            catch
            {
                Console.WriteLine("Не корректный параметр!");
            }*/

            //перемножение матриц
            if (lenth1 == height2)
            {
                try
                {
                    Matrix ResultMatrix = new Matrix();
                    Console.WriteLine("Перемножаем матрицы");
                    int[,] MultiplicationResult = new int[height1, lenth2];
                    for (int i = 0; i < height1; i++)
                    {
                        for (int j = 0; j < lenth2; j++)
                        {
                            MultiplicationResult[i, j] = ResultMatrix.MultMatrixElem(fm, sm, i, j, lenth1);
                        }
                    }
                    ResultMatrix.MatrixOut(MultiplicationResult, height1, lenth2);
                }//try
                catch
                {
                    Console.WriteLine("Проблема с перемножением матриц.");
                }
            }

            else
            {
                Console.WriteLine("Невозможно перемножить матрицы!");
            }

            
            Console.ReadLine();
        }
    }
}
